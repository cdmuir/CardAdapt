# This script copies output from climate analyses to manuscript data folder

# Files that need to be copied:
# ~/Google Drive/CardAdapt/Data/Climate/Robjects/focClim.RData
# *** still need to make focClimSA_62km.RData ***
# ~/Google Drive/CardAdapt/Data/Climate/Robjects/focClimSA_62km.RData
# ~/Google Drive/CardAdapt/Data/Climate/Robjects/thinnedOccClimate.RData
# ~/Google Drive/CardAdapt/Data/Climate/Robjects/clim2lat_fit_t1.RData

files2copy <- c("ExploratoryClimateVariables.RData",
                "focClim.RData", 
                "focClimSA_62km.RData",
                "thinnedOccClimate.RData",
                "thinnedOccLatLon.csv",
                "clim2lat_fit_t1.RData")

# Path to climate output directory
pathClimOut <- "~/Google Drive/CardAdapt/Data/Climate/Robjects/"

# Path to 'Data' directory for ms
pathDatMS <- "~/Google Drive/CardAdapt/ms/Data/"

# Last updated Jan 1, 2017
file.copy(paste(pathClimOut, files2copy, sep = ""),
          paste(pathDatMS, files2copy, sep = ""), overwrite = TRUE)
